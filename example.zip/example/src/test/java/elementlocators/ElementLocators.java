package elementlocators;

import org.openqa.selenium.By;

public class ElementLocators {
	
	public static By UserName =  By.xpath("//input[@name='userName']");
	public static By Password = By.xpath("//input[@name='userPwd']");
	public static By Login = By.xpath("//input[@class='btn']");
	
	
			public static By FirstName =	By.xpath("//input[@id='txtFirstName']");
			public static By LastName =	By.xpath("//input[@id='txtLastName']");
			public static By Email = By.xpath("//input[@id='txtEmail']");
			public static By MobileNo =	By.xpath("//input[@id='txtPhone']");
			public static By Address = By.xpath("//textarea[@name='address1']");
			public static By City =	By.xpath("//select[@name='city']");
			public static By State =	By.xpath("//select[@name='state']");
			public static By Numberofgueststaying =	By.xpath("//select[@name='persons']");
			
			
			
			public static By CardHolderName =	By.xpath("//input[@id='txtCardholderName']");
			public static By DebitCardNumber =	By.xpath("//input[@id='txtDebit']");
			public static By CVV =	By.xpath("//input[@id='txtCvv']");
			public static By ExpirationMonth =	By.xpath("//input[@id='txtMonth']");
			public static By ExpirationYear =	By.xpath("//input[@id='txtYear']");
			public static By ConfirmBooking =	By.xpath("//input[@id='btnPayment']");
			
			
	
}
