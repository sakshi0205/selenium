package stepdefinations;

import org.openqa.selenium.WebDriver;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import elementlocators.ElementLocators;

public class StepDefination {
	WebDriver driver;
	
	@Given("^The User is on HotelBookingApplication Home page$")
	public void the_User_is_on_HotelBookingApplication_Home_page() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	   actions.PageFactory.openbrowser("file:///C:/Users/benaveen/Desktop/Hotel%20booking%20case%20study/login.html");
	}

	@When("^User enters the Username$")
	public void user_enters_the_Username() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		actions.PageFactory.sendvalue(ElementLocators.UserName,"capgemini");
	}

	@When("^Enters the Password$")
	public void enters_the_Password() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		actions.PageFactory.sendvalue(ElementLocators.Password,"capg1234");
	}

	@Then("^User is  successfully logged in$")
	public void user_is_successfully_logged_in() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		actions.PageFactory.clickmethod(ElementLocators.Login);
	}

	@Given("^The User is on HotelBookingApplication Booking Page$")
	public void the_User_is_on_HotelBookingApplication_Booking_Page() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	   // actions.PageFactory.openbrowser("file:///C:/Users/benaveen/Desktop/Hotel%20booking%20case%20study/hotelbooking.html");
	}

	@When("^User enters the First name$")
	public void user_enters_the_First_name() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    actions.PageFactory.sendvalue(ElementLocators.FirstName,"Chris" );
	}

	@When("^Enters the Last name$")
	public void enters_the_Last_name() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    actions.PageFactory.sendvalue(ElementLocators.LastName,"Evans");
	}

	@When("^Enters Email$")
	public void enters_Email() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    actions.PageFactory.sendvalue(ElementLocators.Email, "chris909@capg.com");
	}

	@When("^enters Mobile number$")
	public void enters_Mobile_number() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		actions.PageFactory.sendvalue(ElementLocators.MobileNo, "7894567890");
	}

	@When("^enters Address$")
	public void enters_Address() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		actions.PageFactory.sendvalue(ElementLocators.Address, "T_nagar");
	}

	@When("^select City$")
	public void select_City() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		actions.PageFactory.select(ElementLocators.City, "Chennai");
	}

	@When("^select State$")
	public void select_State() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		actions.PageFactory.select(ElementLocators.State, "Tamilnadu");
	}

	@When("^select Number of guests staying$")
	public void select_Number_of_guests_staying() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		actions.PageFactory.select(ElementLocators.Numberofgueststaying, "2");
	}

	

	@When("^enters Card Holder Name$")
	public void enters_Card_Holder_Name() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		actions.PageFactory.sendvalue(ElementLocators.CardHolderName, "ChrisEvans");
	}

	@When("^enters Debit Card Number$")
	public void enters_Debit_Card_Number() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		actions.PageFactory.sendvalue(ElementLocators.DebitCardNumber, "9874561230");
	}

	@When("^enters cvv$")
	public void enters_cvv() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		actions.PageFactory.sendvalue(ElementLocators.CVV, "3214");
	}

	@When("^enters Expiration Month$")
	public void enters_Expiration_Month() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		actions.PageFactory.sendvalue(ElementLocators.ExpirationMonth, "march");
	}

	@When("^enters Expiration Year$")
	public void enters_Expiration_Year() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		actions.PageFactory.sendvalue(ElementLocators.ExpirationYear, "2011");
	}

	@Then("^User is successfully registered$")
	public void user_is_successfully_registered() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	   actions.PageFactory.clickmethod(ElementLocators.ConfirmBooking);
	}

	@Then("^Browser is closed$")
	public void browser_is_closed() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	  driver.close(); 
	}


}
